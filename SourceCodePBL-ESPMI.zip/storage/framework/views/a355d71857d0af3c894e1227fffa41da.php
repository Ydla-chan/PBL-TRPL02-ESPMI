<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>User Dashboard</h1>
    <?php if(auth()->guard()->check()): ?>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
        </tr>
        <tr>
            <td><?php echo e(auth()->user()->id); ?></td>
            <td><?php echo e(auth()->user()->nama_lengkap); ?></td>
            <td><?php echo e(auth()->user()->email); ?></td>
        </tr>
    </table>
    <?php else: ?>
    <p>Please log in to view the dashboard.</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\PBL\E-SPMI LARAVEL\Backup Githu\RealProject\resources\views\dumb.blade.php ENDPATH**/ ?>